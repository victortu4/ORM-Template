from django.apps import AppConfig


class OrmtemplateappConfig(AppConfig):
    name = 'ormTemplateApp'
