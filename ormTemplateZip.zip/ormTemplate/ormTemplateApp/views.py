from django.shortcuts import render, HttpResponse, redirect
from .models import User



def index(request):
    print(User.objects.all())

    context = {
        "allUsers": User.objects.all()

    }
    return render(request, "index.html", context)

def createUser(request):

    print(request.POST)
    
# ClassName.objects.create(field1="value for field1", field2="value for field2", etc.)
    newUser = User.objects.create(name=request.POST['FullName'], age=request.POST['Age'], email=request.POST['Email'])
    
    return redirect("/")
